# Factory Sensor Telemetry

**Data Quality Assessment · Exploratory Data Analysis · Data Cleaning & Validation**

An applied analysis of synthetic industrial sensor data, assessing data quality and measurement patterns before cleaning treatable issues and validating the results. The project combines statistical analysis, visualization, and methodological documentation so that its workflow can be reviewed and reproduced.

**Prepared by:** Mohammed Muayad Shakir  
**Field:** Data Analytics & Data Preprocessing  
**Tools:** Python · Pandas · NumPy · Matplotlib · Jupyter Notebook

[Analysis notebook](notebooks/01_data_quality_analysis.ipynb) · [Cleaning and validation notebook](notebooks/02_data_cleaning_validation.ipynb) · [Final report](reports/Final_Project_Report.pdf)

## 1. Project Overview

The project connects three areas: **data quality assessment**, **exploratory data analysis (EDA)**, and **cleaning and validation**. Separate notebooks for analysis and cleaning make decisions and outputs explicit and preserve traceability.

| Metric | Value |
| :--- | :---: |
| Original records | 8,000 |
| Raw working-copy records | 8,020 |
| Records after cleaning | 8,000 |
| Columns | 8 |
| Devices and sites | 12 devices across 3 sites |
| Main outputs | Two notebooks, four charts, and a final report |

**Scope:** The project does not train a machine-learning model or diagnose actual faults. Its findings are descriptive and exploratory and are based on synthetic data.

## 2. Dataset and Source

Source: [Datanemics — Factory Sensor Telemetry](https://datanemics.com/datasets/sensor-telemetry/)  
Type: **Synthetic Dataset**  
License stated by the source: [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)

The original data contains readings from 12 devices across `NOR`, `RIV`, and `SLT` during January and February 2023. It simulates unusual patterns, including vibration changes and time gaps. Not every observation discovered in analysis is therefore attributable to the quality issues introduced later.

### Data versions

| File | Use | Records |
| :--- | :--- | ---: |
| [`original_data.csv`](data/original_data.csv) | Original synthetic reference dataset | 8,000 |
| [`raw_data.csv`](data/raw_data.csv) | Working copy with additional quality issues for practice | 8,020 |
| [`cleaned_data.csv`](data/cleaned_data.csv) | Output of cleaning and validation | 8,000 |

The original source is preserved unchanged, and cleaning is performed on the raw working copy. No separate script regenerates the introduced issues, so reproducing analysis and cleaning starts from the supplied `raw_data.csv`.

### Data dictionary

| Column | Description | Unit or values |
| :--- | :--- | :--- |
| `reading_at` | Reading date and time | UTC according to the source description |
| `device_id` | Device identifier | Text code |
| `site` | Device site | `NOR`, `RIV`, `SLT` |
| `status` | Recorded status | `OK`, `WARN`, `FAULT` |
| `temp_c` | Temperature | °C |
| `humidity_pct` | Relative humidity | % |
| `vibration_mm_s` | RMS vibration velocity | mm/s |
| `rpm` | Device shaft rotational speed | Revolutions per minute |

**Technical note:** The source describes timestamps as UTC, but CSV values contain no explicit time-zone information. Analysis retains the supplied timestamps without conversion to local time. RMS means root mean square in the vibration measurement description.

## 3. Project Structure

| Directory or file | Contents |
| :--- | :--- |
| `data/` | `original_data.csv`, `raw_data.csv`, `cleaned_data.csv` |
| `notebooks/` | `01_data_quality_analysis.ipynb`, `02_data_cleaning_validation.ipynb` |
| `charts/` | `temperature_distribution.png`, `mean_vibration_by_site.png`, `daily_vibration_trend.png`, `temperature_vs_vibration_scatter.png` |
| `reports/` | `Final_Project_Report.md`, `Final_Project_Report.pdf` |
| `README.md` | Project overview and reproduction instructions |
| `requirements.txt` | Documented environment dependencies |

The `data` directory holds datasets; `notebooks` contains code, explanations, and outputs; `charts` contains saved figures; and `reports` contains the written final report.

## 4. Methodology

### Quality assessment and exploratory analysis

[`01_data_quality_analysis.ipynb`](notebooks/01_data_quality_analysis.ipynb) documents quality issues and creates an analytical copy after excluding fully duplicated records. It covers:

- Dimensions, types, missing values, duplicates, and formatting differences
- Descriptive statistics, filtering, sorting, `groupby()` aggregation, and pivot tables
- Measurement comparisons by device, site, and operating status, including IQR outlier analysis
- Correlations, daily trends, time gaps, and the derived analytical column `reading_day`
- Visualizations and additional comparisons to check interpretations

The main filters select `FAULT` readings, temperatures above the 90th percentile, and readings from `NOR`.

### Cleaning and validation

[`02_data_cleaning_validation.ipynb`](notebooks/02_data_cleaning_validation.ipynb) processes the same raw input through a separate workflow:

1. Remove fully identical records
2. Convert reading dates to datetime and standardize site and status labels
3. Remove text commas from `rpm` and convert it to numeric values
4. Sort records and save `cleaned_data.csv`
5. Reload the file to validate content, column types, duplicates, and missing values

**Cleaning decision:** Missing values are retained without imputation, outliers without automatic removal, and time gaps without replacement readings, because no evidence establishes the assumed replacement measurements or operational errors.

**Cross-check:** The analytical and cleaned copies are compared after normalization and sorting. All eight thousand records pass under comparison conditions that permit limited differences in data-type representation and numerical rounding.

## 5. Main Findings

### Data quality

| Check | Result |
| :--- | ---: |
| Fully duplicated records | 20 |
| Missing measurement values | 40; 10 per measurement column |
| `site` formatting inconsistencies | 12 |
| `status` formatting inconsistencies | 12 |
| `rpm` values containing text commas | 12 |
| Readings labeled `FAULT` | 124 |
| Temperatures above the 90th percentile (45.151 °C) | 799 |
| Readings from `NOR` | 2,823 |

### Outliers and differences between IQR methods

The global IQR check derives boundaries for each variable from all its valid readings:

| Measurement | Outlying readings |
| :--- | ---: |
| Temperature | 89 |
| Humidity | 49 |
| Vibration | 677 |
| Rotational speed | 61 |

An additional temperature analysis compares global boundaries derived from `OK` readings with per-device boundaries derived from each device's `OK` readings:

| Classification method | Readings |
| :--- | ---: |
| Global `OK`-based boundaries | 133 |
| Per-device `OK`-based boundaries | 89 |
| Flagged by both methods | 88 |
| Global boundaries only | 45 |
| Per-device boundaries only | 1 |
| Differently classified readings | 46 |

**Important clarification:** The original count of 89 uses a different reference population from the additional comparison. The net difference between the two new totals is 44, but 46 individual records change classification.

### Vibration and statistical relationships

| Metric | Result |
| :--- | ---: |
| Mean vibration at `NOR` | 3.3592 mm/s |
| Mean vibration at `RIV` | 2.8044 mm/s |
| Mean vibration at `SLT` | 2.6043 mm/s |
| `NOR` mean excluding `MCH-04` and `MCH-10` from the comparison | 2.7033 mm/s |
| Pearson temperature–vibration correlation | 0.6232 |
| Correlation restricted to `OK` readings | 0.3093 |

Testing `status` consistency against vibration thresholds of 4.2 and 5.5 mm/s gives matching classifications for **7,990 valid readings**. Ten readings with missing vibration are excluded. This checks consistency with a tested rule; it does not establish an actual mechanical fault.

### Trends and time gaps

- **8 long time gaps** occur in four devices at `RIV` and also exist in the original source.
- An estimated **468 potential unrecorded readings** assumes a regular two-hour interval for each device. It is a conditional estimate, not a confirmed missing-record count.
- `MCH-04` and `MCH-10` show upward daily mean-vibration slopes of approximately **0.0540** and **0.0487 mm/s/day**, respectively.
- The **0.02 mm/s/day** threshold is used only for exploratory screening and is not an approved engineering fault-diagnosis limit.

## 6. Charts

Four charts in `charts` support the numerical findings and illustrate the observed differences and trends:

- [Temperature Distribution](charts/temperature_distribution.png) — distribution of recorded temperatures
- [Mean Vibration by Site](charts/mean_vibration_by_site.png) — comparison of site mean vibration
- [Daily Vibration Trend](charts/daily_vibration_trend.png) — daily vibration patterns
- [Temperature vs Vibration](charts/temperature_vs_vibration_scatter.png) — descriptive temperature–vibration relationship

**Example visualization — mean vibration by site:**

![Mean vibration by site](charts/mean_vibration_by_site.png)

## 7. Execution Environment and Reproducibility

The original project documentation records **Python 3.14.7** for the final run, with the dependencies listed in [`requirements.txt`](requirements.txt):

| Library | Version |
| :--- | :---: |
| `pandas` | 3.1.0 |
| `numpy` | 2.5.4 |
| `matplotlib` | 3.11.2 |
| `ipykernel` | 7.4.0 |

Create an isolated environment on Windows from the project root:

```powershell
py -3.14 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Select this environment as the notebook kernel. Set the working directory to `notebooks`, because the notebooks use relative paths to `data` and `charts`. Restart the kernel and run all cells in order.

For a full rebuild from raw data, use this order:

1. **Notebook 02** — clean, validate, and regenerate `cleaned_data.csv`
2. **Notebook 01** — assess quality, perform EDA, update charts, and compare the analytical copy with the regenerated cleaned file
3. **Final verification** — inspect success messages and compare outputs with documented findings

Both notebooks read `raw_data.csv` directly. Notebook 01 also reads `cleaned_data.csv` in an early equivalence check, so it depends on that supplied or regenerated file. The original delivery package already includes it. Rerunning the cleaning notebook overwrites `cleaned_data.csv`, and plotting may update chart files; account for these effects when reproducing a preserved delivery copy.

## 8. Limitations and Future Development

- The data is synthetic rather than actual factory operating records.
- `OK`, `WARN`, and `FAULT` labels do not establish actual mechanical faults.
- Outlier and trend results depend on the reference groups and statistical thresholds selected.
- Correlation does not establish causality, and the available data cannot conclusively explain gaps or elevated vibration.
- The project can later support unusual-pattern detection or machine-learning experiments after defining suitable targets and evaluation criteria.

## 9. Reports and References

Jupyter notebooks provide the code and analytical detail; the report independently presents the methodology, results, and conclusions:

- [Final Project Report — Markdown](reports/Final_Project_Report.md)
- [Final Project Report — PDF](reports/Final_Project_Report.pdf)
- [Dataset Source — Datanemics](https://datanemics.com/datasets/sensor-telemetry/)

**Prepared by: Mohammed Muayad Shakir**

## English Edition Verification

All 99 code cells (11 cleaning, 88 analysis) passed sequential execution in isolated copies using Python 3.12.14, pandas 2.2.3, NumPy 2.3.5, Matplotlib 3.10.8 and IPython 9.18.1. The regenerated cleaned CSV matched the supplied file within relative and absolute tolerances of 1e-12. The original `requirements.txt` pins have been preserved; that exact environment has not been independently reproduced. `requirements-verified.txt` records the analytical packages used in this verification (a Jupyter front end/kernel must also be available to run interactively).

The English edition translates explanatory Markdown. Code cells and their saved outputs are preserved. Browser-readable notebook views are provided on the portfolio; download the ZIP for the relative CSV paths required to run the notebooks.
