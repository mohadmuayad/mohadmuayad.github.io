# Final Report — Industrial Sensor Data Quality Analysis

**Factory Sensor Telemetry — Data Quality, Cleaning & Exploratory Analysis**

**Prepared by:** Mohammed Muayad Shakir  
**Field:** Data Analytics & Data Preprocessing  
**Project type:** Final applied project for an AI Engineering Diploma  
**Report date:** 3 November 2026

## 1. Executive Summary

This project assesses the quality of synthetic industrial sensor data, resolves formatting issues and duplicates, and analyzes measurements to identify patterns and differences across devices, sites, and the recording period. Python, Pandas, NumPy, and Matplotlib were used, with the workflow and checks documented in two separate Jupyter notebooks.

The original dataset contains **8,000 records and 8 columns**, representing **12 devices across 3 sites**. A raw working copy with **8,020 records** was prepared by introducing deliberate quality issues for data-processing practice. Cleaning produced **8,000 records**, preserving missing values and outlying readings where there was insufficient evidence to justify imputation or removal.

The assessment identified **20 fully duplicated records**, **40 missing values**, and formatting inconsistencies in selected columns. Analysis found a positive descriptive relationship between temperature and vibration, most vibration outliers concentrated in two devices, and **8 long time gaps** also present in the original source. An additional check showed that outlier counts depend on how statistical boundaries are derived.

**Main conclusion:** The project achieved its quality-assessment, cleaning, validation, and exploratory-analysis objectives within the context of synthetic data. The statistical indicators do not constitute a confirmed diagnosis of mechanical faults or a forecast of future failures.

## 2. Dataset and Study Scope

### 2.1 Source and nature of the data

The project uses [Datanemics — Factory Sensor Telemetry](https://datanemics.com/datasets/sensor-telemetry/), a **synthetic dataset** simulating industrial sensor readings. The source lists its license as [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).

The data covers **1 January through 28 February 2023**. Devices are distributed across three sites:

- `NOR` — four devices
- `RIV` — four devices
- `SLT` — four devices

Some unusual patterns and time gaps already exist in the original data. This report therefore distinguishes **quality issues added to the training copy** from **properties already present in the synthetic source**.

### 2.2 Data files

| File | Use | Records |
| :--- | :--- | ---: |
| `original_data.csv` | Original synthetic reference data, preserved unchanged | 8,000 |
| `raw_data.csv` | Raw working copy with additional quality issues for practice | 8,020 |
| `cleaned_data.csv` | Output of cleaning and validation | 8,000 |

The project does not include a separate script to recreate the introduced quality issues from the original file. Reproducing the notebook workflow starts from the supplied `raw_data.csv`; `original_data.csv` remains an independent comparison reference.

### 2.3 Columns and measurement units

| Column | Meaning | Unit or value type |
| :--- | :--- | :--- |
| `reading_at` | Reading date and time | UTC according to the source description |
| `device_id` | Device identifier | Text code |
| `site` | Device site | `NOR` / `RIV` / `SLT` |
| `status` | Recorded status category | `OK` / `WARN` / `FAULT` |
| `temp_c` | Temperature | °C |
| `humidity_pct` | Relative humidity | % |
| `vibration_mm_s` | RMS vibration velocity | mm/s |
| `rpm` | Rotational speed | Revolutions per minute |

**Technical note:** The source describes recording times as UTC, but CSV date values do not carry an explicit time zone for each record. The project retains timestamps as supplied without converting them to local time. RMS means **Root Mean Square** in the vibration-velocity measurement description.

### 2.4 Research questions

The study is organized around a main question and supporting questions covering data quality assessment, treatment, and the analysis of operational measurements.

**Main question:**

What is the quality of the factory sensor data, and what patterns and trends appear in measurements across devices, sites, and the study period?

**Supporting questions:**

1. What quality issues exist in the raw data, and how extensive is each issue?
2. Which cleaning procedures can be applied safely, and how can their results be validated?
3. How do temperature, vibration, humidity, and rotational-speed measurements differ across devices and sites?
4. What time trends, gaps, and outliers appear in the data?
5. What are the limits of interpreting the detected patterns, and what additional requirements must be met before future machine-learning use?

## 3. Methodology

The workflow connects understanding and auditing the raw data with cleaning treatable issues, validating results, and presenting exploratory findings visually. Implementation is split between two notebooks to clarify each stage's role and allow decisions and results to be reviewed independently.

### 3.1 Data Quality Assessment

The assessment examines dataset dimensions, column types, fully duplicated rows, device/timestamp keys, missing values, category formatting, and RPM formatting. Descriptive statistics and the **interquartile range (IQR)** method are also used to identify statistically unusual readings.

### 3.2 Data Cleaning

Cleaning is implemented in [`02_data_cleaning_validation.ipynb`](../notebooks/02_data_cleaning_validation.ipynb), starting from the raw copy without changing the original reference file. It removes fully duplicated records, converts dates, normalizes text categories, repairs numeric formatting, sorts records, and saves the cleaned copy.

### 3.3 Data Validation

`assert` checks verify record counts, key uniqueness, column types, category consistency, and missing-value locations. The cleaned file is also reloaded after saving to check content equivalence and the required types under the specified reading settings.

An independent test compares the analytical copy in the assessment notebook with `cleaned_data.csv` after formatting normalization and record sorting. The test compares **8,000 records** and all columns successfully within a small numerical tolerance, allowing differences in programming-language type representation.

### 3.4 Exploratory Data Analysis

Analysis is implemented in [`01_data_quality_analysis.ipynb`](../notebooks/01_data_quality_analysis.ipynb). It includes descriptive statistics, filtering, sorting, grouping with `groupby()`, pivot tables, correlations, daily trends, and time gaps.

The derived column `reading_day` is created from reading timestamps within the temporal-analysis data to support daily grouping. It is not added to the raw or cleaned CSV files.

### 3.5 Execution Environment and Reproducibility

The original project documentation records successful execution of both notebooks from a fresh Jupyter kernel using **Python 3.14.7**, with the versions listed in `requirements.txt`: **Pandas 3.1.0**, **NumPy 2.5.4**, **Matplotlib 3.11.2**, and **ipykernel 7.4.0**.

The notebooks use relative paths from the `notebooks` directory. Running the cleaning notebook saves `cleaned_data.csv` again. Rerun effects must therefore be considered when preparing a delivery package. Detailed execution instructions are provided in [`README.md`](../README.md). The analysis notebook includes an early comparison against the supplied cleaned file; regenerate that file with Notebook 02 first when reproducing all outputs from raw data.

## 4. Data Quality Findings

### 4.1 Issues identified in the raw working copy

| Check | Result |
| :--- | ---: |
| Raw dataset size | 8,020 rows × 8 columns |
| Fully duplicated rows | 20 |
| Missing measurement values | 40 |
| Missing values in each measurement column | 10 |
| Site-code formatting inconsistencies | 12 |
| Operating-status formatting inconsistencies | 12 |
| RPM values containing thousands separators | 12 |
| Invalid dates | 0 |
| Long time gaps observed | 8 |

**Interpretation:** Duplicates, numeric separators, and inconsistent category spelling can be treated directly. Missing values, time gaps, and outlying readings cannot be assigned replacement values or discarded without additional reliable information.

### 4.2 Missing-value distribution

There are **40 missing values**, evenly distributed across four numeric columns:

| Column | Missing values |
| :--- | ---: |
| `temp_c` | 10 |
| `humidity_pct` | 10 |
| `vibration_mm_s` | 10 |
| `rpm` | 10 |
| **Total** | **40** |

By site, missing values total **26 in `NOR`**, **8 in `RIV`**, and **6 in `SLT`**. This indicates unequal distribution across sites but does not establish a specific operational cause.

## 5. Cleaning and Validation

### 5.1 Cleaning decision log

| Issue | Selected treatment | Rationale |
| :--- | :--- | :--- |
| 20 fully duplicated records | Remove duplicate records | Prevent counting a reading more than once |
| Dates stored as text | Convert `reading_at` to datetime | Support time sorting and calculations |
| Inconsistent `site` and `status` formatting | Trim whitespace and standardize case | Ensure consistent grouping and categorization |
| Thousands separators in `rpm` | Remove commas, then convert to numeric values | Enable correct numerical operations |
| Missing values | Preserve without imputation | Avoid inventing undocumented measurements |
| Outliers | Preserve without automatic removal | No engineering evidence establishes that they are errors |
| Time gaps | Do not generate replacement records | No reference confirms the unrecorded readings |

After processing, records are sorted by reading timestamp and device identifier, then saved to `cleaned_data.csv`.

### 5.2 Cleaning results

| Validation metric | Result after cleaning |
| :--- | :---: |
| Records | 8,000 |
| Columns | 8 |
| Fully duplicated records | 0 |
| Missing values | 40, retained without imputation |
| Site and status formatting | Standardized |
| Numeric and datetime types after reloading | Passed |
| Saved file matches cleaning output | Passed |
| Analytical and cleaned data equivalent after normalization | Passed |

**Methodological clarification:** CSV does not independently store programming-language data types; these are determined when the file is reloaded with the selected settings. Equivalence checks allow specified small differences in numeric and type representation and do not constitute engineering validation of measurement accuracy.

## 6. Exploratory Analysis Results

### 6.1 Filtering and grouping

The project uses filters for different purposes, including isolating `FAULT` readings, temperatures above the 90th percentile, and readings from `NOR`. Groupings and comparisons by site, device, and status are complemented by device ranking and a mean-vibration pivot table.

| Filtering metric | Result |
| :--- | ---: |
| `FAULT` readings | 124 |
| Temperature 90th percentile | 45.151 °C |
| Readings above the 90th percentile | 799 |
| `NOR` readings | 2,823 |

Of the **799 readings** above the temperature 90th percentile, **414** are labeled `OK`, **274** `WARN`, and **111** `FAULT`. A relatively high-temperature classification therefore does not, on its own, match the operating-status categories.

### 6.2 IQR outliers

The original outlier check uses global boundaries calculated separately for each variable from all its valid readings after duplicate removal.

| Measurement | Outlying readings | Approximate share of 8,000 records |
| :--- | ---: | ---: |
| Temperature | 89 | 1.1% |
| Humidity | 49 | 0.6% |
| Vibration | 677 | 8.5% |
| Rotational speed | 61 | 0.8% |

**650 of the 677 vibration outliers** occur in two devices: **419 in `MCH-04`** and **231 in `MCH-10`**, approximately **96%** of all vibration outliers under this definition.

This concentration identifies a useful focus for investigation and comparison. It does not establish that all flagged readings are incorrect or that the two devices suffered confirmed faults.

### 6.3 Comparing two temperature-outlier methods

An additional comparison illustrates how results depend on the **reference population used to derive IQR boundaries**. Both new methods derive boundaries from readings labeled `OK`, then apply them to all temperature readings:

- **Method 1:** One global set of boundaries derived from `OK` readings across all devices
- **Method 2:** Separate boundaries for each device, derived from that device's `OK` readings

| Comparison result | Readings |
| :--- | ---: |
| Outliers under global `OK`-based boundaries | 133 |
| Outliers under per-device `OK`-based boundaries | 89 |
| Outliers under both methods | 88 |
| Outliers under global boundaries only | 45 |
| Outliers under per-device boundaries only | 1 |
| Readings classified differently | 46 |

**Interpretation:** The difference between the totals is **44 readings**, whereas **46 individual records** change classification because one reading is flagged only by the per-device boundaries. `MCH-06` also has two differently classified records despite identical outlier counts under the two methods.

**Essential distinction:** The **89** temperature outliers in the original IQR check are derived using all valid temperature readings. The **89** under Method 2 result from per-device boundaries derived from `OK` readings. Equal totals do not imply the same method or the same records.

### 6.4 Mean vibration across sites

| Site | Mean vibration |
| :--- | ---: |
| `NOR` | 3.3592 mm/s |
| `RIV` | 2.8044 mm/s |
| `SLT` | 2.6043 mm/s |

`NOR` has the highest overall mean. However, its mean falls to **2.7033 mm/s** when `MCH-04` and `MCH-10` are excluded from **this analytical comparison only**, placing it below `RIV`.

Site averages can therefore be strongly influenced by particular devices. It would be inappropriate to assume that every device at `NOR` shares the same vibration level. Neither device's readings are removed from the original or cleaned files.

### 6.5 Temperature–vibration correlation

| Reading group | Pearson correlation coefficient |
| :--- | ---: |
| Analytical dataset | 0.6232 |
| Readings labeled `OK` only | 0.3093 |

The positive correlation indicates that temperature and vibration tend to rise together in the studied data. The lower coefficient within `OK` readings shows that relationship strength depends on the composition of the group used for calculation.

Correlation does not establish that higher temperature causes higher vibration or vice versa, and it is insufficient by itself to diagnose device condition.

### 6.6 Consistency of status labels with vibration

An exploratory test compares `status` labels with two vibration thresholds: **4.2** and **5.5 mm/s**. Labels match the tested rule in all **7,990 readings** with available vibration values, with no mismatches.

| Category | Readings matching the rule |
| :--- | ---: |
| `OK` | 7,387 |
| `WARN` | 481 |
| `FAULT` | 122 |
| **Total testable readings** | **7,990** |

**10 readings** cannot be tested because vibration is missing despite an available status label: **7 `OK`**, **1 `WARN`**, and **2 `FAULT`**.

**Interpretation limits:** The test establishes consistency of valid values with the tested rule. It does not prove that this rule originally generated the labels or that it is an approved engineering fault standard.

### 6.7 Time gaps and device coverage

The analysis identifies **8 long time gaps** across four devices at `RIV`:

`MCH-02` · `MCH-05` · `MCH-08` · `MCH-11`

Each device has two gaps. Four gaps last **4 days and 22 hours**; the other four last **5 days**. They occur in two periods during January and February 2023 and are confirmed in `original_data.csv`, before the working copy's quality issues were introduced.

The dataset spans **59 days**. Eight devices have readings on all 59 days; each of the four gap-affected devices has readings on **51 days**. Daily coverage alone does not imply that all expected readings are available within each day.

Assuming a typical interval of **two hours between consecutive readings from the same device**, an estimated **468 potential unrecorded readings** fall inside these gaps. This is conditional on the observed recording pattern; it is not a confirmed missing-reading count or evidence of the cause of recording interruptions.

### 6.8 Daily vibration trends

Daily means show upward slopes for the following devices:

| Device | Approximate daily slope |
| :--- | ---: |
| `MCH-04` | 0.0540 mm/s/day |
| `MCH-10` | 0.0487 mm/s/day |

A threshold of **0.02 mm/s/day** is used as an exploratory screening criterion for more pronounced upward trends. Only these two devices exceed it in the implemented check.

**Methodological note:** The threshold is an analytical choice, not an approved engineering standard. An upward slope does not establish mechanical deterioration or an imminent fault, particularly in synthetic data.

## 7. Data Visualization

Four charts linked to the preceding results are saved in `charts`. They visually support the numerical findings without replacing the tests or methodological evidence.

### 7.1 Temperature distribution

![Distribution of recorded temperatures](../charts/temperature_distribution.png)

**Figure 1:** Shows the temperature distribution and concentrations of readings, helping describe its overall spread and values far from the densest part of the distribution.

### 7.2 Mean vibration by site

![Mean vibration across sites](../charts/mean_vibration_by_site.png)

**Figure 2:** Shows differences between the three sites' overall means and complements the comparison identifying the effect of two high-reading devices on `NOR`'s mean.

### 7.3 Daily vibration trend

![Daily mean vibration trends](../charts/daily_vibration_trend.png)

**Figure 3:** Compares daily trends for `MCH-04` and `MCH-10` with a reference group of six devices with complete daily coverage. The reference mean supports descriptive comparison.

### 7.4 Temperature–vibration relationship

![Temperature versus vibration](../charts/temperature_vs_vibration_scatter.png)

**Figure 4:** Shows an overall positive association, consistent with the calculated Pearson coefficient. Neither the point pattern nor the correlation alone supports a causal conclusion.

## 8. Discussion and Key Findings

The project shows that data inspection extends beyond removing duplicates or normalizing column formats. Recording quality, reference-group selection, and statistical boundaries influence the resulting indicators and interpretations.

The main findings are:

1. **Verifiable treatment:** Duplicates and formatting differences were resolved without missing-value imputation or unjustified outlier removal.
2. **Concentration of high vibration:** `MCH-04` and `MCH-10` contribute substantially to vibration outliers and to the mean at `NOR`.
3. **Sensitivity of outlier definitions:** IQR results change when the reference population changes. The identities of flagged records can change even when totals match.
4. **Correlation depends on the group:** Overall correlation exceeds the correlation calculated using only `OK` readings.
5. **Gaps are not necessarily introduced by processing:** Long gaps exist in the original synthetic source. Estimated unrecorded-reading counts depend on an assumption of regular recording.
6. **Programmatic validation is not engineering validation:** Consistent types, labels, and files verify specific processing steps but do not turn measurements or labels into evidence of actual faults.

## 9. Study Limitations

- The data is synthetic rather than actual factory operating records; results cannot be generalized to real equipment without external validation.
- Independent technical specifications are unavailable to establish safe operating limits or explain high measurements.
- A `FAULT` label does not establish a documented mechanical fault.
- IQR results depend on the reference population and boundary definitions. Outliers are not necessarily errors.
- Estimates of unrecorded readings rely on observed time intervals, not a confirmed official sampling schedule.
- Correlations and daily trends do not establish causality or predictive capability.
- The project provides no independent log of actual fault events or their timing and does not train a machine-learning model.

## 10. Recommendations and Future Development

The findings support the following recommendations for similar industrial data:

1. **Preserve reference and raw data** to maintain traceability and enable repeated cleaning and comparison.
2. **Document cleaning decisions**, distinguishing formatting-invalid values from statistically unusual ones.
3. **Use approved operating limits when available** before interpreting outlying readings as actual faults.
4. **Verify the sampling policy** to distinguish operational gaps from permitted intervals between measurements.
5. **Review the source of status labels** before using `status` as a classification target.
6. **Verify reproducibility** by rerunning both notebooks and comparing outputs and saved files with documented results.

**Development opportunities:** The cleaned data can support future machine-learning experiments such as unusual-pattern analysis. A reliable predictive-maintenance model would require a clearly defined target, suitable data on fault events and timing, and an evaluation design that prevents future-information leakage (**data leakage**).

## 11. Project Files and References

| Component | File |
| :--- | :--- |
| Quality-assessment and analysis notebook | [`01_data_quality_analysis.ipynb`](../notebooks/01_data_quality_analysis.ipynb) |
| Cleaning and validation notebook | [`02_data_cleaning_validation.ipynb`](../notebooks/02_data_cleaning_validation.ipynb) |
| Original data | [`original_data.csv`](../data/original_data.csv) |
| Raw data | [`raw_data.csv`](../data/raw_data.csv) |
| Cleaned data | [`cleaned_data.csv`](../data/cleaned_data.csv) |
| Charts | [`charts/`](../charts/) |
| Project description and reproduction instructions | [`README.md`](../README.md) |
| Environment dependencies | [`requirements.txt`](../requirements.txt) |

**References:**

- [Datanemics — Factory Sensor Telemetry](https://datanemics.com/datasets/sensor-telemetry/) — synthetic dataset source and technical description
- [Creative Commons — CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) — text of the license stated by the source
- Supplied project notebooks and CSV files — reference for calculations, analyses, and validation procedures

## 12. Conclusion

The project completes a workflow of **understanding, assessing, cleaning, validating, analyzing, and visualizing data**. Checks show that the cleaned and analytical datasets are equivalent under the comparison conditions and that key numerical results can be recalculated from the project files.

Differences in device behavior, time gaps, and outliers warrant investigation but do not independently establish operational causes or diagnose faults. The project therefore provides a **documented foundation for industrial data analysis** and a starting point for more advanced experiments once the required data and evaluation criteria are available.

**Prepared by: Mohammed Muayad Shakir**
